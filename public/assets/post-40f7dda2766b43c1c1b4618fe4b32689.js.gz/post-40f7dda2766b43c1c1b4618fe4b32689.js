$(function(){
  SyntaxHighlighter.all();
});
