(function() {
  var $;

  $ = jQuery;

  $("#list input.toggle").live("click", function() {
    return $("#list [name='bulk_ids[]']").attr("checked", $(this).is(":checked"));
  });

  $('.pjax').live('click', function(event) {
    if (event.which > 1 || event.metaKey || event.ctrlKey) {

    } else if ($.support.pjax) {
      event.preventDefault();
      return $.pjax({
        container: $(this).data('pjax-container') || '[data-pjax-container]',
        url: $(this).data('href') || $(this).attr('href'),
        timeout: 2000
      });
    } else if ($(this).data('href')) {
      return window.location = $(this).data('href');
    }
  });

  $('.pjax-form').live('submit', function(event) {
    if ($.support.pjax) {
      event.preventDefault();
      return $.pjax({
        container: $(this).data('pjax-container') || '[data-pjax-container]',
        url: this.action + (this.action.indexOf('?') !== -1 ? '&' : '?') + $(this).serialize(),
        timeout: 2000
      });
    }
  });

  $(document).on('pjax:start', function() {
    return $('#loading').show();
  }).on('pjax:end', function() {
    return $('#loading').hide();
  });

  $('[data-target]').live('click', function() {
    if (!$(this).hasClass('disabled')) {
      if ($(this).has('i.icon-chevron-down').length) {
        $(this).removeClass('active').children('i').toggleClass('icon-chevron-down icon-chevron-right');
        return $($(this).data('target')).select(':visible').hide('slow');
      } else {
        if ($(this).has('i.icon-chevron-right').length) {
          $(this).addClass('active').children('i').toggleClass('icon-chevron-down icon-chevron-right');
          return $($(this).data('target')).select(':hidden').show('slow');
        }
      }
    }
  });

  $('.form-horizontal legend').live('click', function() {
    if ($(this).has('i.icon-chevron-down').length) {
      $(this).siblings('.control-group:visible').hide('slow');
      return $(this).children('i').toggleClass('icon-chevron-down icon-chevron-right');
    } else {
      if ($(this).has('i.icon-chevron-right').length) {
        $(this).siblings('.control-group:hidden').show('slow');
        return $(this).children('i').toggleClass('icon-chevron-down icon-chevron-right');
      }
    }
  });

  $(document).ready(function() {
    return $(document).trigger('rails_admin.dom_ready');
  });

  $(document).live('pjax:end', function() {
    return $(document).trigger('rails_admin.dom_ready');
  });

  $(document).live('rails_admin.dom_ready', function() {
    $('.animate-width-to').each(function() {
      var length, width;
      length = $(this).data("animate-length");
      width = $(this).data("animate-width-to");
      return $(this).animate({
        width: width
      }, length, 'easeOutQuad');
    });
    return $('.form-horizontal legend').has('i.icon-chevron-right').each(function() {
      return $(this).siblings('.control-group').hide();
    });
  });

}).call(this);
