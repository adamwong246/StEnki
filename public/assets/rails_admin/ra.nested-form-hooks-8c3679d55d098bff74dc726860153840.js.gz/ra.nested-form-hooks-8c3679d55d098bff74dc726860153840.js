(function() {
  var $;

  $ = jQuery;

  $(document).ready(function() {
    return window.nestedFormEvents.insertFields = function(content, assoc, link) {
      var tab_content;
      tab_content = $(link).closest(".controls").siblings(".tab-content");
      tab_content.append(content);
      return tab_content.children().last();
    };
  });

  $('form').live('nested:fieldAdded', function(content) {
    var controls, field, nav, new_tab, parent_group, toggler;
    field = content.field.addClass('tab-pane');
    new_tab = $('<li><a data-toggle="tab" href="#' + field.attr('id') + '">' + field.children('.object-infos').data('object-label') + '</a></li>');
    parent_group = field.closest('.control-group');
    controls = parent_group.children('.controls');
    nav = controls.children('.nav');
    content = parent_group.children('.tab-content');
    toggler = controls.find('.toggler');
    nav.append(new_tab);
    $(window.document).trigger('rails_admin.dom_ready');
    new_tab.children('a').tab('show');
    nav.select(':hidden').show('slow');
    content.select(':hidden').show('slow');
    return toggler.addClass('active').removeClass('disabled').children('i').addClass('icon-chevron-down').removeClass('icon-chevron-right');
  });

  $('form').live('nested:fieldRemoved', function(content) {
    var controls, current_li, field, nav, parent_group, toggler;
    field = content.field;
    nav = field.closest(".control-group").children('.controls').children('.nav');
    current_li = nav.children('li').has('a[href=#' + field.attr('id') + ']');
    parent_group = field.closest(".control-group");
    controls = parent_group.children('.controls');
    toggler = controls.find('.toggler');
    (current_li.next().length ? current_li.next() : current_li.prev()).children('a:first').tab('show');
    current_li.remove();
    if (nav.children().length === 0) {
      nav.select(':visible').hide('slow');
      return toggler.removeClass('active').addClass('disabled').children('i').removeClass('icon-chevron-down').addClass('icon-chevron-right');
    }
  });

}).call(this);
